﻿using System;

namespace Calculadora
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var x = Calculo.Somar(1, 1);
        }
    }
}
