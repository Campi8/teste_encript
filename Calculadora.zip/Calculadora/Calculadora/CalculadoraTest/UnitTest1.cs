using Calculadora;
using System;
using Xunit;

namespace CalculadoraTest
{
    public class UnitTest1
    {
        [Fact(DisplayName ="Teste de Soma")]
        [Trait("Calculo", "Somar")]
        public void Somar_DoisDouble_RetornarDouble()
        {
            //Arrange
            var num1 = 2.9;
            var num2 = 3.1;
            var valorEsperado = 6;

            //Act
            var soma = Calculo.Somar(num1, num2);

            //Assert
            Assert.Equal(valorEsperado, soma);
        }


        // para pular o metodo d eteste [Fact(Skip = "Teste ainda n�o dispon�vel")]
        [Fact(DisplayName = "Teste de Subtra��o")]
        [Trait("Calculo", "Subtrair")]
        public void Subtrair_DoisNumerosDouble_RetornarDouble()
        {
            //Arrange
            var num1 = 8;
            var num2 = 6;
            var valorEsperado = 2;

            //Act
            var subtracao = Calculo.Subtrair(num1, num2);

            //Assert
            Assert.Equal(valorEsperado, subtracao);

        }


        [Fact(DisplayName = "Teste de Multiplicar")]
        [Trait("Calculo", "Multiplicar")]
        public void Multiplicar_DoisDouble_RetornarDouble()
        {
            //Arrange
            var num1 = 7;
            var num2 = 7;
            var valorEsperado = 49;

            //Act
            var multiplicacao = Calculo.Multiplicar(num1, num2);

            //Assert
            Assert.Equal(valorEsperado, multiplicacao);

        }


        [Fact(DisplayName = "Teste de Divis�o")]
        [Trait("Calculo", "Dividir")]
        public void Dividir_DoisDouble()
        {
            //Arrange
            var num1 = 10;
            var num2 = 2;
            var valorEsperado = 5;

            //Act
            var dividir = Calculo.Dividir(num1, num2);

            //Assert
            Assert.Equal(valorEsperado, dividir);

        }


        [Fact(DisplayName = "Teste para saber se � numero par")]
        [Trait("Calculo", "Outros")]
        public void Validar_NumeroPar_RetornarBoolean()
        {
            //Arrange
            var num1 = 2;
            var valorEsperado = true;

            //Act
            var par = Calculo.EhNumeroPar(num1);

            //Assert
            Assert.Equal(valorEsperado, par);

        }

    }
}
