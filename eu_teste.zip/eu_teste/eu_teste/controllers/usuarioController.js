const CryptoJS = require('crypto-js');
const { Usuario } = require('../models/usuario');

module.exports = {
  criarUsuario: async (req, res) => {
    const { nome, senha } = req.body;

    try {
      const senhaCriptografada = CryptoJS.SHA256(senha).toString();

      await Usuario.create({ nome, senha: senhaCriptografada });

      res.send('Usuário criado com sucesso!');
    } catch (error) {
      console.error(error);
      res.status(500).send('Ocorreu um erro ao criar o usuário.');
    }
  }
};
