const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const routes = require('./routes');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

// Configuração do Sequelize
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize('cyber', 'root', '', {
  host: 'localhost',
  dialect: 'mysql'
});

const Usuario = require('./models/usuario')(sequelize, DataTypes);

// Sincroniza o modelo com o banco de dados
sequelize.sync();

// Define as rotas
app.use('/', routes);

// Define o caminho para as views
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'html');
app.engine('html', require('ejs').renderFile);

// Inicia o servidor
app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000');
});
