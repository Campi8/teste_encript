module.exports = {
    development: {
      database: 'cyber',
      username: 'root',
      password: '',
      host: 'localhost',
      dialect: 'mysql'
    }
  };
  