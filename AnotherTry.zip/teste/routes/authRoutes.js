const express = require('express');
const router = express.Router();

// Rota para a página inicial
router.get('/', (req, res) => {
  res.render('index');
});

// Rota para a página de registro
router.get('/registro', (req, res) => {
  res.render('registro');
});

// Rota para a página de login
router.get('/login', (req, res) => {
  res.render('login');
});

// Rota para a página do painel (dashboard)
router.get('/dashboard', (req, res) => {
  const user = req.session.user;
  if (user) {
    res.render('dashboard', { user });
  } else {
    req.flash('error_msg', 'Você precisa estar logado para acessar o painel');
    res.redirect('/login');
  }
});

// Rota para fazer logout
router.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    res.redirect('/login');
  });
});

module.exports = router;
