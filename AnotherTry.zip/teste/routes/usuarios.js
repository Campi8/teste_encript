const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Rota para registrar um usuário
router.post('/registro', (req, res) => {
  const { nome, senha } = req.body;

  // Criptografar a senha antes de salvar no banco de dados
  const senhaCriptografada = // Use um algoritmo de hash (por exemplo, bcrypt)

  db.query('INSERT INTO users (nome, senha) VALUES (?, ?)', [nome, senhaCriptografada], (error, results) => {
    if (error) {
      console.error(error);
      return res.redirect('/registro');
    }
    req.flash('success_msg', 'Usuário registrado com sucesso!');
    res.redirect('/login');
  });
});

// Rota para autenticar um usuário
router.post('/login', (req, res) => {
  const { nome, senha } = req.body;

  db.query('SELECT * FROM users WHERE nome = ?', [nome], (error, results) => {
    if (error) {
      console.error(error);
      return res.redirect('/login');
    }

    // Verificar a senha descriptografando-a e comparando com a senha no banco de dados

    if (senhaCorreta) {
      req.session.user = results[0];
      res.redirect('/dashboard');
    } else {
      req.flash('error_msg', 'Credenciais inválidas');
      res.redirect('/login');
    }
  });
});

module.exports = router;
