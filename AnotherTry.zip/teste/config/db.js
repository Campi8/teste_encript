const mysql = require('mysql');

const db = mysql.createConnection({
  host: 'db4free.net',
  user: 'anakamy',
  password: 'cybersafezon',
  database: 'cybersafezon'
});

module.exports = db;




