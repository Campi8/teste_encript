const express = require('express');
const session = require('express-session');
const flash = require('express-flash');
const path = require('path');
const exphbs = require('express-handlebars');


const app = express();

// Configurar Handlebars como template engine
app.engine('.hbs', exphbs.engine({ extname: '.hbs', defaultLayout: "main"}));
app.set('view engine', 'hbs');

// Middleware para servir arquivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Configurar sessões
app.use(session({
  secret: 'suaChaveSecreta',
  resave: true,
  saveUninitialized: true
}));

// Configurar flash messages
app.use(flash());

// Conectar ao banco de dados
const db = require('./config/db');
db.connect();

// Definir rotas
app.use('/', require('./routes/authRoutes'));
app.use('/usuarios', require('./routes/usuarios'));

// Iniciar servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
