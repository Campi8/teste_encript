﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace Etec.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlunoController : ControllerBase
    {
        [HttpGet("obter-aluno")]
        public IActionResult Obter()
        {
            return Ok("Gustavo");
            
        }


        [HttpGet("listar-alunos")]
        public IActionResult Listar()
        {
            var nomes = new List<string>();
            nomes.Add("Priscila");
            nomes.Add("Rafael");
            nomes.Add("Joao Pedro");
            nomes.Add("Rafael Luz");
            nomes.Add("Igor");
            nomes.Add("Wellington");
            nomes.Add("Ruan");
            nomes.Add("Calera");
            nomes.Add("Olga");
            nomes.Add("Jao Alves");
            nomes.Add("Ana");
            nomes.Add("Isaque");
            nomes.Add("Cazuro");
            nomes.Add("Leandro");
            nomes.Add("Ana Carolina");
            nomes.Add("Kamily");
            nomes.Add("Gustavo");
            nomes.Add("Joao Victor");

            //return Ok(nomes.OrderBy(n => n));
            return Ok(nomes.Where(n => n.ToLower().StartsWith("j")));

        }


    }
}